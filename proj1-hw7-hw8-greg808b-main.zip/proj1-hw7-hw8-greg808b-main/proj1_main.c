/* DriverLib Includes */
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>

/* HAL and Application includes */
#include <Application.h>
#include <HAL/HAL.h>
#include <HAL/Timer.h>


void circleisKill(Application* app_p, HAL* hal_p);
int InterpretInput(char rxChar, Application* app_p);
void Initialize(Graphics_Context* g_sContext_p);
/**
 * The main entry point of your project. The main function should immediately
 * stop the Watchdog timer, call the Application constructor, and then
 * repeatedly call the main super-loop function. The Application constructor
 * should be responsible for initializing all hardware components as well as all
 * other finite state machines you choose to use in this project.
 *
 * THIS FUNCTION IS ALREADY COMPLETE. Unless you want to temporarily experiment
 * with some behavior of a code snippet you may have, we DO NOT RECOMMEND
 * modifying this function in any way.
 */
int main(void)
{
    // Stop Watchdog Timer - THIS SHOULD ALWAYS BE THE FIRST LINE OF YOUR MAIN
    WDT_A_holdTimer();

    // Initialize the system clock and background hardware timer, used to enable
    // software timers to time their measurements properly.
    InitSystemTiming();

    // Initialize the main Application object and HAL object
    HAL hal = HAL_construct();
    Application app = Application_construct();



    // Main super-loop! In a polling architecture, this function should call
    // your main FSM function over and over.
    while (true)
    {
        HAL_refresh(&hal);
        Application_loop(&app, &hal);
    }
}

/**
 * A helper function which increments a value with a maximum. If incrementing
 * the number causes the value to hit its maximum, the number wraps around
 * to 0.
 */
uint32_t CircularIncrement(uint32_t value, uint32_t maximum)
{
    return (value + 1) % maximum;
}

/**
 * The main constructor for your application. This function should initialize
 * each of the FSMs which implement the application logic of your project.
 *
 * @return a completely initialized Application object
 */
Application Application_construct()
{
    Application app;

    // Initialize local application state variables here!
    app.baudChoice = BAUD_9600;
    app.firstCall = true;
    app.age = 0;
    app.happy = 5;
    app.energy = 5;
    app.x=63;
    app.y=80;
    app.state=egg;
    app.moves=0;

    // a 3-second timer (i.e. 3000 ms as specified in the SWTimer_contruct)
    app.threeSecondTimer = SWTimer_construct(3000);
    SWTimer_start(&app.threeSecondTimer);

    return app;
}

/**
 * The main super-loop function of the application. We place this inside of a
 * single infinite loop in main. In this way, we can model a polling system of
 * FSMs. Every cycle of this loop function, we poll each of the FSMs one time,
 * followed by refreshing all inputs to the system through a convenient
 * [HAL_refresh()] call.
 *
 * @param app_p:  A pointer to the main Application object.
 * @param hal_p:  A pointer to the main HAL object
 */
void Application_loop(Application* app_p, HAL* hal_p)
{
    // The obligatory non-blocking check. At any time in your code, pressing and
    // holding Launchpad S1 should always turn on Launchpad LED1.
    //
    // Not a real TODO: Ensure that your code never blocks turning on this LED.
    if (Button_isPressed(&hal_p->launchpadS1))
        LED_turnOn(&hal_p->launchpadLED1);
    else
        LED_turnOff(&hal_p->launchpadLED1);

    // Restart/Update communications if either this is the first time the application is
    // run or if Boosterpack S2 is pressed (which means a new baudrate is being set up)
    if (Button_isTapped(&hal_p->boosterpackS2) || app_p->firstCall) {
        Application_updateCommunications(app_p, hal_p);
        clearPosition(app_p,hal_p);

    }

    // A 3-second timer is repeatedly started, whenever it expires 1 year is added to the age
    if (SWTimer_expired(&app_p->threeSecondTimer))
    {
        SWTimer_start(&app_p->threeSecondTimer);
        //check if egg has been warmed
        if(app_p->state==0&&app_p->moves>4){
            app_p->state=child;
            app_p->moves=0;
        }
        //dead if not warmed
        else if(app_p->state==0){
            app_p->state=dead;
            clearPosition(app_p,hal_p);

        }
        //increment age happy and energy
        app_p->age +=1;
        if((app_p->happy>0))
        app_p->happy -=1;
        if((app_p->energy>0))
        app_p->energy -=1;
        if(app_p->state<3){
            //check condition for adult
        if((app_p->age>3)&&(app_p->happy>3)&&(app_p->energy>3)){
            app_p->state=adult;
        }
        //check if dead from no energy and happy
        if((app_p->happy<1)&&(app_p->energy<1)){
            app_p->state=dead;
        }
        clearPosition(app_p,hal_p);
    }
    }

    if (UART_hasChar(&hal_p->uart)) {
        // The character received from your serial terminal
        char rxChar = UART_getChar(&hal_p->uart);
        int status = InterpretInput(rxChar, app_p);
        if(status==2){
            //if fed
            clearPosition(app_p,hal_p);
        }
        else if(status==1){
            //if moved and check if 2 for happy and 3 for energy
            if((app_p->moves%2==0)&&(app_p->happy<5))
                        app_p->happy +=1;
                    if(app_p->moves%3==0)
                        app_p->energy -=1;

                    clearPosition(app_p,hal_p);
        }

        char txChar = Application_interpretIncomingChar(rxChar);

        // Only send a character if the UART module can send it
        if (UART_canSend(&hal_p->uart))
            UART_putChar(&hal_p->uart, txChar);
    }

}

/**
 * Updates which LEDs are lit and what baud rate the UART module communicates
 * with, based on what the application's baud choice is at the time this
 * function is called.
 *
 * @param app_p:  A pointer to the main Application object.
 * @param hal_p:  A pointer to the main HAL object
 */
//command for dead state to be displayed
void circleisKill(Application* app_p, HAL* hal_p){
Graphics_setForegroundColor(&hal_p->g_sContext,GRAPHICS_COLOR_BLACK);
    Graphics_Rectangle R;
    R.xMin = 23;
    R.xMax = 103;
    R.yMin = 63;
    R.yMax = 127;
Graphics_fillRectangle(&hal_p->g_sContext, &R);
Graphics_fillCircle(&hal_p->g_sContext, 63, 63, 40);
Graphics_setForegroundColor(&hal_p->g_sContext,GRAPHICS_COLOR_WHITE);
Graphics_drawString(&hal_p->g_sContext, "R.I.P.",-1,52,63, false);
}
//clears screen and rewrites all stats/position of thing
void clearPosition(Application* app_p, HAL* hal_p){
    //draw white rectangle over whole display
    Graphics_setForegroundColor(&hal_p->g_sContext,GRAPHICS_COLOR_WHITE);
    Graphics_Rectangle R;
    R.xMin = 0;
    R.xMax = 127;
    R.yMin = 0;
    R.yMax = 127;
    Graphics_fillRectangle(&hal_p->g_sContext,&R);
    Graphics_setForegroundColor(&hal_p->g_sContext,GRAPHICS_COLOR_BLACK);
    //check if dead
    if(app_p->state==3){
        circleisKill(app_p,hal_p);
    }
    else{
    //redraw all HUD
    int size = 0;
    //determine size of tamagotchi based off state
    if(app_p->state>1)
        size=15;
    else if(app_p->state>0)
        size=10;
    else size=5;
    Graphics_fillCircle(&hal_p->g_sContext, app_p->x, app_p->y, size);
    char printer[50];
    int i=0;
    sprintf(printer,"AGE: %d",app_p->age);
    Graphics_drawString(&hal_p->g_sContext, (int8_t *)printer, -1, 0, 0, false);
    char star[10];
    //empty string
    for(i=0;i<10;i++)
        star[i]=' ';
    for(i=0;i<app_p->happy;i++)
        star[i]='o';
    sprintf(printer,"HAPPY: %s ",star);
    Graphics_drawString(&hal_p->g_sContext, (int8_t *)printer, -1, 0, 105, false);
    //empty string
    for(i=0;i<10;i++)
            star[i]=' ';
        for(i=0;i<app_p->energy;i++)
            star[i]='o';
        sprintf(printer,"ENERGY: %s ",star);
    Graphics_drawString(&hal_p->g_sContext, (int8_t *)printer, -1, 0, 117, false);
    sprintf(printer,"BR: %d",app_p->baudChoice);
    Graphics_drawString(&hal_p->g_sContext, (int8_t *)printer, -1, 83, 0, false);
    Graphics_drawLineH(&hal_p->g_sContext,10,117,15);
    Graphics_drawLineH(&hal_p->g_sContext,10,117,100);
    Graphics_drawLineV(&hal_p->g_sContext,10,15,100);
    Graphics_drawLineV(&hal_p->g_sContext,117,15,100);
    }
}
void Application_updateCommunications(Application* app_p, HAL* hal_p)
{
    // When this application first loops, the proper LEDs aren't lit. The
    // firstCall flag is used to ensure that the
    if (app_p->firstCall) {
        app_p->firstCall = false;
    }

    // When Boosterpack S1 is tapped, circularly increment which baud rate is used.
    else
    {
        uint32_t newBaudNumber = CircularIncrement((uint32_t) app_p->baudChoice, NUM_BAUD_CHOICES);
        app_p->baudChoice = (UART_Baudrate) newBaudNumber;
    }

    // Start/update the baud rate according to the one set above.
    UART_SetBaud_Enable(&hal_p->uart, app_p->baudChoice);

    // Based on the new application choice, turn on the correct LED.
    // To make your life easier, we recommend turning off all LEDs before
    // selectively turning back on only the LEDs that need to be relit.
    // -------------------------------------------------------------------------
    LED_turnOff(&hal_p->boosterpackRed);
    LED_turnOff(&hal_p->boosterpackGreen);
    LED_turnOff(&hal_p->boosterpackBlue);

    // TODO: Turn on all appropriate LEDs according to the tasks below.
    switch (app_p->baudChoice)
    {
        // When the baud rate is 9600, turn on Boosterpack LED Red
        case BAUD_9600:
            LED_turnOn(&hal_p->boosterpackRed);
            break;

        // TODO: When the baud rate is 19200, turn on Boosterpack LED Green
        case BAUD_19200:
            LED_turnOn(&hal_p->boosterpackGreen);
            break;

        // TODO: When the baud rate is 38400, turn on Boosterpack LED Blue
        case BAUD_38400:
            LED_turnOn(&hal_p->boosterpackBlue);
            break;

        // TODO: When the baud rate is 57600, turn on all Boosterpack LEDs (illuminates white)
        case BAUD_57600:
            LED_turnOn(&hal_p->boosterpackRed);
            LED_turnOn(&hal_p->boosterpackGreen);
            LED_turnOn(&hal_p->boosterpackBlue);
            break;

        // In the default case, this program will do nothing.
        default:
            break;
    }
}

/**
 * Interprets a character which was incoming and returns an interpretation of
 * that character. If the input character is a letter, it return L for Letter, if a number
 * return N for Number, and if something else, it return O for Other.
 *
 * @param rxChar: Input character
 * @return :  Output character
 */
char Application_interpretIncomingChar(char rxChar)
{
    // The character to return back to sender. By default, we assume the letter
    // to send back is an 'O' (assume the character is an "other" character)
    char txChar = 'O';

    // Numbers - if the character entered was a number, transfer back an 'N'
    if (rxChar >= 'w' && rxChar <= '9') {
        txChar = 'N';
    }

    // Letters - if the character entered was a letter, transfer back an 'L'
    if ((rxChar >= 'a' && rxChar <= 'z') || (rxChar >= 'A' && rxChar <= 'Z')) {
        txChar = 'L';
    }


    return (txChar);
}
//function to check if input has required action
int InterpretInput(char rxChar, Application* app_p){
int move = 0;
//f = feed
if(rxChar=='f'&&app_p->energy<5){
  app_p->energy +=1;
  move = 2;

            }
//check movement and if able (energy>0 and not at border)
if(app_p->state>0&&app_p->energy>0){
if(rxChar=='w'&&((app_p->y-20)>10)){
 app_p->y -=5;
 move = 1;
app_p->moves+=1;
    }
if(rxChar=='s'&&((app_p->y+20)<100)){
    app_p->y +=5;
    move = 1;
    app_p->moves+=1;
        }
if(rxChar=='a'&&((app_p->x-20)>10)){
    move = 1;
    app_p->x -=5;
    app_p->moves+=1;
}
if(rxChar=='d'&&((app_p->x+20)<117)){
    app_p->x +=5;
    move = 1;
    app_p->moves+=1;
        }
}
//extra for warmth of egg
if(app_p->state==0&&rxChar=='w'){
app_p->moves +=1;
}
return move;
}


